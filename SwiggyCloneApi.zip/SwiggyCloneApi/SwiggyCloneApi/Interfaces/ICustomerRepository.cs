﻿using SwiggyCloneApi.Models;

namespace SwiggyCloneApi.Interfaces
{
    public interface ICustomerRepository
    {
        ICollection<Customer> GetCustomers();
        Customer GetCustomer(int id);
        bool CustomerExists(int id);
        Product GetProduct(int id);

        ResponseModel CreateCustomer(Customer customer);
        ResponseModel UpdateCustomer(Customer customer);
        ResponseModel DeleteCustomer(int id);
    }
}
