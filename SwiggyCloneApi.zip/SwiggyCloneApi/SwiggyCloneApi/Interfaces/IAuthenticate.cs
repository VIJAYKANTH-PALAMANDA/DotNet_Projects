﻿using SwiggyCloneApi.Models;
using SwiggyCloneApi.UserAuth;

namespace SwiggyCloneApi.Interfaces
{
    public interface IAuthenticate
    {
        ResponseModel Register(CustomerRegister customerRegister);
        string Login(CustomerLoginDTO customer);
    }
}
