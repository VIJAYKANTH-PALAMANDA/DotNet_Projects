﻿using SwiggyCloneApi.Models;

namespace SwiggyCloneApi.Interfaces
{
    public interface IProductRepository
    {
        ICollection<Product> GetProducts();
        Product GetProduct(int id);
        ResponseModel CreateProduct(Product product);
        ResponseModel UpdateProduct(Product product);
        ResponseModel DeleteProduct(int id);
        bool ProductExists(int id);
    }
}
