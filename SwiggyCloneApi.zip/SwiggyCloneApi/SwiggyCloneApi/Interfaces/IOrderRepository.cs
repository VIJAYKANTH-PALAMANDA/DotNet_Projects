﻿using SwiggyCloneApi.Models;

namespace SwiggyCloneApi.Interfaces
{
    public interface IOrderRepository
    {
        ICollection<Order> GetOrders();

        Order GetOrder(int id);
        ResponseModel AddOrder(Order order);
        ResponseModel DeleteOrder(int id);
        ResponseModel UpdateOrder(Order order);
        bool OrderExists(int id);
    }
}
