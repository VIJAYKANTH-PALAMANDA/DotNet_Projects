﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SwiggyCloneApi.Interfaces;
using SwiggyCloneApi.Models;
using SwiggyCloneApi.Repository;

namespace SwiggyCloneApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        public OrderController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Order>))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [AllowAnonymous]
        public IActionResult GetOrders()
        {
            var orders = _orderRepository.GetOrders();
            if (orders == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            return Ok(orders);
        }

        [HttpGet("{OrderId}")]
        [ProducesResponseType(200, Type = typeof(Order))]
        [ProducesResponseType(404)]
        public IActionResult GetOrder(int OrderId)
        {
            if(!_orderRepository.OrderExists(OrderId))
                return NotFound();
            var order = _orderRepository.GetOrder(OrderId);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            return Ok(order);
        }

        [HttpPost]
        public IActionResult AddOrde(Order order)
        {
            if (_orderRepository.OrderExists(order.Id))
                return Conflict();//409
            var response = _orderRepository.AddOrder(order);
            if (!ModelState.IsValid)
                return BadRequest();//400
            return Ok(response);
        }

        [HttpPut]
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateOrder(Order order)
        {
            ResponseModel response;
            if (_orderRepository.OrderExists(order.Id))
                response = _orderRepository.UpdateOrder(order);
            else
                response = _orderRepository.AddOrder(order);
            if (!ModelState.IsValid)
                return BadRequest();//400
            return Ok(response);
        }

        [HttpDelete]
        public IActionResult DeleteOrder(int id)
        {
            ResponseModel response;
            if (_orderRepository.OrderExists(id))
                response = _orderRepository.DeleteOrder(id);
            else
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();//400
            return Ok(response);
        }


    }
}
