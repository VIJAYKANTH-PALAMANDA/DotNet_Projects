﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SwiggyCloneApi.Interfaces;
using SwiggyCloneApi.UserAuth;

namespace SwiggyCloneApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly IAuthenticate _service;
        public AuthenticateController(IAuthenticate service)
        {
            _service = service;
        }

        [HttpPost("register")]
        public IActionResult register(CustomerRegister customer)
        {
            var response = _service.Register(customer);
            return Ok(response);
        }

        [HttpPost("login")]
        public IActionResult login(CustomerLoginDTO customer)
        {
            var token = _service.Login(customer);
            return Ok(token);
        }
    }
}
