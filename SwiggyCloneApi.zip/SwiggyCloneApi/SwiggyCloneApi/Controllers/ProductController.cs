﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SwiggyCloneApi.Interfaces;
using SwiggyCloneApi.Models;

namespace SwiggyCloneApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    [Authorize]
    public class ProductController : ControllerBase
    {
        private IProductRepository _productRepository;
        public ProductController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Product>))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [AllowAnonymous]
        public IActionResult GetProducts()
        {
            var products = _productRepository.GetProducts();
            if(products == null) 
                return NotFound();
            if(!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(products);
        }

        [HttpGet("{ProductId}")]
        [ProducesResponseType(200, Type=typeof(Product))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult GetProduct(int ProductId)
        {
            if (!_productRepository.ProductExists(ProductId))
                return NotFound();
            var product = _productRepository.GetProduct(ProductId);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(product);
        }
        [HttpDelete]
        [ProducesResponseType(200, Type = typeof(ResponseModel))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult DeleteProduct(int id)
        {
            if (!_productRepository.ProductExists(id))
                return NotFound();
            var response = _productRepository.DeleteProduct(id);
            if (!ModelState.IsValid)
                return BadRequest();
            return Ok(response);

        }

        [HttpPost]
        [ProducesResponseType(200, Type = typeof(ResponseModel))]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]//Conflict
        public IActionResult CreateProduct(Product product)
        {
            if (_productRepository.ProductExists(product.ProductId))
                return Conflict();
            var response = _productRepository.CreateProduct(product);
            if (!ModelState.IsValid)
                return BadRequest();
            return Ok(response);
        }

        [HttpPut]
        [ProducesResponseType(200, Type = typeof(ResponseModel))]
        [ProducesResponseType(400)]
        public IActionResult UpdateProduct(Product product)
        {
            var response = _productRepository.UpdateProduct(product);
            if (!ModelState.IsValid)
                return BadRequest();
            return Ok(response);

        }

    }
}
