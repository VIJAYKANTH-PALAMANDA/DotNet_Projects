﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SwiggyCloneApi.Interfaces;
using SwiggyCloneApi.Models;
using SwiggyCloneApi.Repository;

namespace SwiggyCloneApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepository _customerRepository;

        public CustomerController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        [HttpGet]
        [ProducesResponseType(200, Type=typeof(IEnumerable<Customer>))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [AllowAnonymous]
        public IActionResult GetCustomers()
        {
            var customers = _customerRepository.GetCustomers();
            if (customers == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            return Ok(customers);
        }

        [HttpGet("product")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Customer>))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [AllowAnonymous]
        public IActionResult Getproduct(int id)
        {
            var product = _customerRepository.GetProduct(id);
            if (product == null)
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();
            return Ok(product);
        }



        [HttpGet("{CustomerId}")]
        [ProducesResponseType(200, Type = typeof(Customer))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult GetCustomer(int CustomerId)
        {
            if(!_customerRepository.CustomerExists(CustomerId))
                return NotFound();
            var customer = _customerRepository.GetCustomer(CustomerId);
            if (!ModelState.IsValid)
                return BadRequest();
            return Ok(customer);
        }

        [HttpPost]
        public IActionResult AddCustomer(Customer customer)
        {
            if (_customerRepository.CustomerExists(customer.Id))
                return Conflict();//409
            var response = _customerRepository.CreateCustomer(customer);
            if (!ModelState.IsValid)
                return BadRequest();//400
            return Ok(response);
        }

        [HttpPut]
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateCustomer(Customer customer)
        {
            ResponseModel response;
            if (_customerRepository.CustomerExists(customer.Id))
                response = _customerRepository.UpdateCustomer(customer);
            else
                response = _customerRepository.CreateCustomer(customer);
            if (!ModelState.IsValid)
                return BadRequest();//400
            return Ok(response);
        }

        [HttpDelete]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteCustomer(int id)
        {
            ResponseModel response;
            if (_customerRepository.CustomerExists(id))
                response = _customerRepository.DeleteCustomer(id);
            else
                return NotFound();
            if (!ModelState.IsValid)
                return BadRequest();//400
            return Ok(response);
        }





    }
}
