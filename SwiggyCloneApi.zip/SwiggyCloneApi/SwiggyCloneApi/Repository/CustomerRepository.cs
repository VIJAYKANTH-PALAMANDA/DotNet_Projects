﻿using Microsoft.EntityFrameworkCore;
using SwiggyCloneApi.Data;
using SwiggyCloneApi.Interfaces;
using SwiggyCloneApi.Models;

namespace SwiggyCloneApi.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        private DataContext _context;
        private readonly IProductRepository _product;
        public CustomerRepository(DataContext context, IProductRepository product)
        {
            _context = context;
            _product = product;
        }

        public ResponseModel CreateCustomer(Customer customer)
        {
            try
            {
                ResponseModel response = new ResponseModel();
                _context.Customers.Add(customer);
                _context.SaveChanges();
                response.IsSuccess = true;
                response.Message = "Customer Added Successfully.";
                return response;
            }
            catch (Exception)
            {

                throw;
            } 
        }

        public bool CustomerExists(int id)
        {
            try
            {
                return _context.Customers.Any(x => x.Id == id);
            }
            catch (Exception)
            {

                throw;
            } 
        }

        public Customer GetCustomer(int id)
        {
            try
            {
                var customer = _context.Customers.Where(c => c.Id == id).Select(c => new Customer()
                {
                    Id = c.Id,
                    FirstName = c.FirstName,
                    LastName = c.LastName,
                    Address = c.Address,
                    Phone = c.Phone,
                    Email = c.Email,
                    Orders = c.Orders.Where(x => x.CustomerId == id).Select(o => new Order()
                    {
                        Id = o.Id,
                        CustomerId = o.CustomerId,
                        Cost = o.Cost,
                        Status = o.Status,
                        Products = o.Products.Where(p => p.OrderId == o.Id).ToList()
                    }).ToList()
                }).FirstOrDefault();
                return customer;
            }
            catch (Exception)
            {

                throw;
            }   
        }

        public ResponseModel DeleteCustomer(int id)
        {
            try
            {
                ResponseModel response = new ResponseModel();
                var customer = _context.Customers.Where(c => c.Id == id).Include(
                    c => c.Orders.Where(o =>
                    o.CustomerId == id)).First();
                _context.Customers.Remove(customer);
                _context.SaveChanges();
                response.IsSuccess = true;
                response.Message = "Customer Deleted Successfully.";
                return response;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public ICollection<Customer> GetCustomers()
        {
            try
            {
                var customer = _context.Customers.Select(c => new Customer()
                {
                    Id = c.Id,
                    FirstName = c.FirstName,
                    LastName = c.LastName,
                    Address = c.Address,
                    Phone = c.Phone,
                    Email = c.Email,
                    Orders = c.Orders.Where(x => x.CustomerId == c.Id).Select(o => new Order()
                    {
                        Id = o.Id,
                        CustomerId = o.CustomerId,
                        Cost = o.Cost,
                        Status = o.Status,
                        Products = o.Products.Where(p => p.OrderId == o.Id).ToList()
                    }).ToList()
                }).ToList();
                return customer;
            }
            catch (Exception)
            {

                throw;
            } 
        }

        public ResponseModel UpdateCustomer(Customer customer)
        {
            try
            {
                ResponseModel response = new ResponseModel();
                _context.Customers.Update(customer);
                _context.SaveChanges();
                response.IsSuccess = true;
                response.Message = "Customer Updated Successfully.";
                return response;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public Product GetProduct(int id)
        {
            Product product = null;
            product = _product.GetProduct(id);
            return product;
        }
    }
}
