﻿using Microsoft.IdentityModel.Tokens;
using SwiggyCloneApi.Data;
using SwiggyCloneApi.Interfaces;
using SwiggyCloneApi.Models;
using SwiggyCloneApi.UserAuth;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;

namespace SwiggyCloneApi.Repository
{
    public class Authenticate : IAuthenticate
    {
        private DataContext _context;
        private IConfiguration _configuration;

        public Authenticate(DataContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public string Login(CustomerLoginDTO customer)
        {
            Customer response = null;
            if (string.IsNullOrEmpty(customer.UserName) || string.IsNullOrEmpty(customer.Password))
                return "Invalid Credentails.";
            
            if (_context.Customers.Where(x => x.Username == customer.UserName).FirstOrDefault() == null)
                return "Invalid User Name.";
            else
            {
                response = _context.Customers.Where(x => x.Username == customer.UserName).FirstOrDefault();

            }

            if (!VerifyPasswordHash(customer.Password, response.PasswordHash, response.PasswordHash))
                return "Invalid Password.";

            string token = CreateToken(response);
            return token;

        }

        public ResponseModel Register(CustomerRegister customerRegister)
        {
            ResponseModel responseModel = new ResponseModel();
            if (CustomerExists(customerRegister.Id))
            {
                responseModel.IsSuccess = false;
                responseModel.Message = "User Already Exists.";
            }
            

            CreatePasswordHash(customerRegister.Password, out Byte[] passwordHash, out Byte[] passwordSalt);
            Customer customer = new Customer()
            {
                Id = customerRegister.Id,
                FirstName = customerRegister.FirstName,
                LastName = customerRegister.LastName,
                Email = customerRegister.Email,
                Address = customerRegister.Address,
                Phone = customerRegister.Phone,
                Username = customerRegister.Username,
                Role = customerRegister.Role,
                PasswordHash = passwordHash,
                PasswordSalt = passwordSalt,
            };

            _context.Add(customer);
            _context.SaveChanges();
            responseModel.IsSuccess = true;
            responseModel.Message = "Registered Successfully.";
            return responseModel;
        }
        
        public bool CustomerExists(int id)
        {
            return _context.Customers.Any(x => x.Id == id);
        }

        private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }
        
        private bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            using(var hamc = new HMACSHA512(passwordSalt))
            {
                var ComputedHash = hamc.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return ComputedHash.SequenceEqual(ComputedHash);
            }
        }
    
        private string CreateToken(Customer customer)
        {
            List<Claim> claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, customer.Username),
                new Claim(ClaimTypes.Role, customer.Role),
            };

            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(
                _configuration.GetSection("Keys:key").Value));

            var cred = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: cred
                );
            var jwt = new JwtSecurityTokenHandler().WriteToken(token);
            return jwt;
        }
    }
}
