﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using SwiggyCloneApi.Data;
using SwiggyCloneApi.Interfaces;
using SwiggyCloneApi.Models;

namespace SwiggyCloneApi.Repository
{
    public class OrderRepository:IOrderRepository
    {
        private DataContext _context;
        public OrderRepository(DataContext context)
        {
            _context = context;
        }

        public ResponseModel AddOrder(Order order)
        {
            try
            {
                ResponseModel response = new ResponseModel();
                _context.Orders.Add(order);
                _context.SaveChanges();
                response.IsSuccess = true;
                response.Message = "Order Added Successfully.";
                return response;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public ResponseModel DeleteOrder(int id)
        {
            try
            {
                ResponseModel response = new ResponseModel();
                var order = _context.Orders.Where(o => o.Id == id).Include(p => p.Products.Where(p => p.OrderId == id)).First();
                _context.Orders.Remove(order);
                _context.SaveChanges();
                response.IsSuccess = true;
                response.Message = "Order Deleted Successfully.";
                return response;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public Order GetOrder(int id)
        {
            try
            {
                var order = _context.Orders.Where(x => x.Id == id).Select(o => new Order()
                {
                    Id = o.Id,
                    CustomerId = o.CustomerId,
                    Cost = o.Cost,
                    Status = o.Status,
                    Products = o.Products.Where(p => p.OrderId == o.Id).ToList()
                }).FirstOrDefault();
                return order;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public ICollection<Order> GetOrders()
        {
            try
            {
                var order = _context.Orders.Select(o => new Order()
                {
                    Id = o.Id,
                    CustomerId = o.CustomerId,
                    Cost = o.Cost,
                    Status = o.Status,
                    Products = o.Products.Where(p => p.OrderId == o.Id).ToList()
                }).ToList();
                return order;
            }
            catch (Exception)
            {

                throw;
            }
            
        }
        public bool OrderExists(int id)
        {
            try
            {
                return _context.Orders.Any(p => p.Id == id);
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public ResponseModel UpdateOrder(Order order)
        {
            try
            {
                ResponseModel response = new ResponseModel();
                _context.Orders.Update(order);
                _context.SaveChanges();
                response.IsSuccess = true;
                response.Message = "Order Updated Successfully.";
                return response;
            }
            catch (Exception)
            {

                throw;
            }
            
        }
    }
}
