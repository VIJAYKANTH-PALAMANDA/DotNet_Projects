﻿using SwiggyCloneApi.Data;
using SwiggyCloneApi.Interfaces;
using SwiggyCloneApi.Models;

namespace SwiggyCloneApi.Repository
{
    public class ProductRepository:IProductRepository
    {
        private readonly DataContext _context;
        public ProductRepository(DataContext Context)
        {
            _context = Context;
        }

        public ResponseModel CreateProduct(Product product)
        {
            try
            {
                _context.Products.Add(product);
                _context.SaveChanges();
                ResponseModel responseModel = new ResponseModel();
                responseModel.IsSuccess = true;
                responseModel.Message = "Product Added Successfully.";
                return responseModel;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public ResponseModel DeleteProduct(int id)
        {
            try
            {
                var product = _context.Products.Where(p => p.ProductId == id).FirstOrDefault();
                _context.Products.Remove(product);
                _context.SaveChanges();
                ResponseModel response = new ResponseModel();
                response.IsSuccess = true;
                response.Message = "Deleted Successfully.";
                return response;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public Product GetProduct(int id)
        {
            try
            {
                var product = _context.Products.Where(p => p.ProductId == id).FirstOrDefault();
                return product;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public ICollection<Product> GetProducts()
        {
            try
            {
                return _context.Products.OrderBy(p => p.ProductId).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        public bool ProductExists(int id)
        {
            bool exists;
            try
            {
                exists = _context.Products.Any(p => p.ProductId == id);
            }
            catch (Exception)
            {

                throw;
            }
            return exists;
        }

        public ResponseModel UpdateProduct(Product product)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                if (ProductExists(product.ProductId))
                {
                    _context.Products.Update(product);
                    _context.SaveChanges();
                    response.IsSuccess = true;
                    response.Message = "Product Updated Successfully.";
                }
                else
                {
                    _context.Products.Add(product);
                    _context.SaveChanges();
                    response.IsSuccess = true;
                    response.Message = "Product Added Successfully.";
                }
            }
            catch (Exception)
            {

                throw;
            }
            return response;   
        }
    }
}
