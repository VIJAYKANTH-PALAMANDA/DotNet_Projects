﻿namespace SwiggyCloneApi.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int Cost { get; set; }
        public Type2 Status { get; set; }

        public int? CustomerId { get; set; }
        public ICollection<Product> Products { get; set; }
    }

    public enum Type2
    {
        Ordered, Packed, Shipped, Delivered
    }
}
