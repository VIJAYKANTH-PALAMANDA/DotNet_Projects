﻿namespace SwiggyCloneApi.Models
{
    public class ProductOrders
    {
        public int ProductId { get; set; }
        public int OrderID { get; set; }
        public ICollection<Product> product { get; set;}
        public ICollection<Order> order { get; set; }
    }
}
