﻿namespace SwiggyCloneApi.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string? ProductName { get; set; }
        public Type ProductType { get; set; }
        public int ProductCost { get; set; }
        public int ProductQuantity { get; set; }

        public int? OrderId { get; set; }
    }
    public enum Type
    {
        Veg, Non_Veg
    }
}
